package `in`.ivwebworks.card

import android.content.Context

object Prefs {
    private const val FILE = "ivwebworks"
    private const val KEY_URL = "card_url"

    fun cardUrl(ctx: Context): String =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_URL, null) ?: ctx.getString(R.string.default_card_url)

    fun setCardUrl(ctx: Context, url: String) =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY_URL, url.trim()).apply()
}
