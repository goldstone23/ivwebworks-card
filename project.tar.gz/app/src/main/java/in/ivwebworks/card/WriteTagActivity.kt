package `in`.ivwebworks.card

import android.app.PendingIntent
import android.content.Intent
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NdefFormatable
import android.os.Build
import android.os.Bundle
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Writes the card link onto a blank NFC card / sticker. */
class WriteTagActivity : AppCompatActivity() {

    private var adapter: NfcAdapter? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_write)
        status = findViewById(R.id.writeStatus)
        findViewById<TextView>(R.id.writeUrl).text = Prefs.cardUrl(this)
        findViewById<android.view.View>(R.id.doneBtn).setOnClickListener { finish() }
        adapter = NfcAdapter.getDefaultAdapter(this)

        // gentle pulse so it feels alive while waiting
        findViewById<ImageView>(R.id.logo).startAnimation(AlphaAnimation(0.55f, 1f).apply {
            duration = 900; repeatMode = Animation.REVERSE; repeatCount = Animation.INFINITE
        })
    }

    override fun onResume() {
        super.onResume()
        val a = adapter ?: run { status.text = getString(R.string.nfc_missing); return }
        if (!a.isEnabled) { status.text = getString(R.string.nfc_off); return }
        val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), flags
        )
        a.enableForegroundDispatch(this, pi, null, null)
    }

    override fun onPause() {
        super.onPause()
        adapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val tag: Tag = (if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)) ?: return
        write(tag)
    }

    private fun write(tag: Tag) {
        val message = NdefMessage(arrayOf(NdefRecord.createUri(Prefs.cardUrl(this))))
        try {
            Ndef.get(tag)?.let { ndef ->
                ndef.connect()
                if (!ndef.isWritable) throw IllegalStateException("tag is read-only")
                if (ndef.maxSize < message.toByteArray().size) throw IllegalStateException("tag is too small")
                ndef.writeNdefMessage(message)
                ndef.close()
                done(); return
            }
            NdefFormatable.get(tag)?.let { f ->
                f.connect(); f.format(message); f.close()
                done(); return
            }
            throw IllegalStateException("this tag type is not supported")
        } catch (e: Exception) {
            status.text = getString(R.string.write_fail, e.message ?: e.javaClass.simpleName)
        }
    }

    private fun done() {
        status.text = getString(R.string.write_ok)
        Toast.makeText(this, R.string.write_ok, Toast.LENGTH_SHORT).show()
    }
}
