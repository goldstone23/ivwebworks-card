package `in`.ivwebworks.card

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.nfc.NfcAdapter
import android.nfc.cardemulation.CardEmulation
import android.content.ComponentName
import android.os.Bundle
import android.os.Build
import android.content.ContentValues
import android.provider.MediaStore
import android.util.Base64
import androidx.core.content.FileProvider
import java.io.File
import android.provider.ContactsContract
import android.text.InputType
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.inflateMenu(R.menu.main_menu)
        toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_write -> startActivity(Intent(this, WriteTagActivity::class.java))
                R.id.action_link -> askForLink()
                R.id.action_help -> AlertDialog.Builder(this)
                    .setTitle(R.string.menu_help).setMessage(R.string.help_text)
                    .setPositiveButton("OK", null).show()
            }
            true
        }

        status = findViewById(R.id.status)
        web = findViewById(R.id.web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.setBackgroundColor(0xFF050B1C.toInt())
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.scheme == "file") return false          // our own page
                return try { startActivity(Intent(Intent.ACTION_VIEW, url)); true } catch (e: Exception) { false }
            }
        }
        web.loadUrl("file:///android_asset/card.html")
    }

    override fun onResume() {
        super.onResume()
        updateNfcStatus()
    }

    private fun updateNfcStatus() {
        val adapter = NfcAdapter.getDefaultAdapter(this)
        status.text = when {
            adapter == null -> getString(R.string.nfc_missing)
            !adapter.isEnabled -> getString(R.string.nfc_off)
            else -> {
                // Ask Android to route the NDEF tag AID to us while this screen is open.
                runCatching {
                    CardEmulation.getInstance(adapter)
                        .setPreferredService(this, ComponentName(this, CardHceService::class.java))
                }
                getString(R.string.tap_ready)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        NfcAdapter.getDefaultAdapter(this)?.let {
            runCatching { CardEmulation.getInstance(it).unsetPreferredService(this) }
        }
    }

    private fun askForLink() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setText(Prefs.cardUrl(this@MainActivity))
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.menu_link)
            .setMessage("This is the link other phones open when they tap you, and the link written to physical cards.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val v = input.text.toString().trim()
                if (v.startsWith("http")) { Prefs.setCardUrl(this, v); toast("Saved") } else toast("Link must start with https://")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    /** Functions the card page can call (window.Android.*). */
    inner class Bridge {
        @JavascriptInterface
        fun savePdf(base64: String, fileName: String) {
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                // 1) Save a copy to Downloads (Android 10+)
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                        put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                    }
                    contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)?.let { uri ->
                        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    }
                }
                // 2) Open the share sheet so it can go straight to WhatsApp, email, etc.
                val dir = File(cacheDir, "shared").apply { mkdirs() }
                val file = File(dir, fileName).apply { writeBytes(bytes) }
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", file)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread {
                    toast(if (Build.VERSION.SDK_INT >= 29) "Saved to Downloads" else "Contact card ready")
                    startActivity(Intent.createChooser(send, "Share contact card"))
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Could not save PDF: ${e.message}") }
            }
        }

        @JavascriptInterface
        fun copy(text: String) {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("IV WebWorks", text))
        }

        @JavascriptInterface
        fun share(text: String) {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            startActivity(Intent.createChooser(i, "Share card"))
        }

        @JavascriptInterface
        fun saveContact(name: String, phone: String, email: String, company: String, role: String, website: String) {
            val i = Intent(ContactsContract.Intents.Insert.ACTION).apply {
                type = ContactsContract.RawContacts.CONTENT_TYPE
                putExtra(ContactsContract.Intents.Insert.NAME, name)
                putExtra(ContactsContract.Intents.Insert.PHONE, phone)
                putExtra(ContactsContract.Intents.Insert.EMAIL, email)
                putExtra(ContactsContract.Intents.Insert.COMPANY, company)
                putExtra(ContactsContract.Intents.Insert.JOB_TITLE, role)
                putExtra(ContactsContract.Intents.Insert.NOTES, website)
            }
            startActivity(i)
        }
    }
}
