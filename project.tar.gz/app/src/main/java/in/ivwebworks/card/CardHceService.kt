package `in`.ivwebworks.card

import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.cardemulation.HostApduService
import android.os.Bundle

/**
 * Makes this phone behave like an NFC Forum Type 4 tag that holds one URL record.
 * Any phone that reads NFC tags (Android, or iPhone XS and newer with the screen on)
 * will read the link and offer to open it — no app needed on the other side.
 */
class CardHceService : HostApduService() {

    companion object {
        private val OK = hex("9000")
        private val FILE_NOT_FOUND = hex("6A82")
        private val WRONG_OFFSET = hex("6B00")
        private val INS_NOT_SUPPORTED = hex("6D00")

        private val NDEF_AID = hex("D2760000850101")
        private val CC_FILE_ID = hex("E103")
        private val NDEF_FILE_ID = hex("E104")

        // Capability Container: len 15, mapping v2.0, MLe 0x00FF, MLc 0x00FF,
        // NDEF file control TLV -> file E104, max size 0x0400, read allowed, write locked.
        private val CC_FILE = hex("000F2000FF00FF0406E104040000FF")

        private const val INS_SELECT: Byte = 0xA4.toByte()
        private const val INS_READ_BINARY: Byte = 0xB0.toByte()

        private fun hex(s: String): ByteArray =
            ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    private var selectedFile: ByteArray? = null
    private var ndefFile: ByteArray = byteArrayOf()

    private fun buildNdefFile(): ByteArray {
        val msg = NdefMessage(NdefRecord.createUri(Prefs.cardUrl(this))).toByteArray()
        return byteArrayOf((msg.size shr 8).toByte(), (msg.size and 0xFF).toByte()) + msg
    }

    override fun processCommandApdu(apdu: ByteArray, extras: Bundle?): ByteArray {
        if (apdu.size < 4) return INS_NOT_SUPPORTED
        val ins = apdu[1]
        val p1 = apdu[2].toInt() and 0xFF
        val p2 = apdu[3].toInt() and 0xFF

        when (ins) {
            INS_SELECT -> {
                if (apdu.size < 5) return FILE_NOT_FOUND
                val lc = apdu[4].toInt() and 0xFF
                if (apdu.size < 5 + lc) return FILE_NOT_FOUND
                val data = apdu.copyOfRange(5, 5 + lc)
                return when (p1) {
                    0x04 -> if (data.contentEquals(NDEF_AID)) {   // select NDEF application
                        selectedFile = null
                        ndefFile = buildNdefFile()
                        OK
                    } else FILE_NOT_FOUND
                    0x00 -> if (data.contentEquals(CC_FILE_ID) || data.contentEquals(NDEF_FILE_ID)) {
                        selectedFile = data
                        OK
                    } else FILE_NOT_FOUND
                    else -> FILE_NOT_FOUND
                }
            }
            INS_READ_BINARY -> {
                val file = when {
                    selectedFile?.contentEquals(CC_FILE_ID) == true -> CC_FILE
                    selectedFile?.contentEquals(NDEF_FILE_ID) == true -> ndefFile
                    else -> return FILE_NOT_FOUND
                }
                val offset = (p1 shl 8) or p2
                var le = if (apdu.size > 4) apdu[4].toInt() and 0xFF else 0
                if (le == 0) le = 256
                if (offset > file.size) return WRONG_OFFSET
                val end = minOf(file.size, offset + le)
                return file.copyOfRange(offset, end) + OK
            }
            else -> return INS_NOT_SUPPORTED
        }
    }

    override fun onDeactivated(reason: Int) {
        selectedFile = null
    }
}
